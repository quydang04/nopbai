﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab02_03a
{
    public partial class Form1 : Form
    {
        private Dictionary<Button, int> seatButtons = new Dictionary<Button, int>();
        private HashSet<int> soldSeats = new HashSet<int>();
        private HashSet<int> selectedSeats = new HashSet<int>();

        public Form1()
        {
            InitializeComponent();
            InitializeSeats();
        }

        private void InitializeSeats()
        {
            int seatNumber = 1;
            for (int row = 0; row < 4; row++)
            {
                for (int col = 0; col < 5; col++)
                {
                    Button seatButton = new Button();
                    seatButton.Width = 50;
                    seatButton.Height = 50;
                    seatButton.Left = 50 + col * 60;
                    seatButton.Top = 50 + row * 60;
                    seatButton.Text = seatNumber.ToString();
                    seatButton.Tag = seatNumber;
                    seatButton.BackColor = Color.White;
                    seatButton.Click += SeatButton_Click;

                    seatButtons.Add(seatButton, seatNumber);
                    this.Controls.Add(seatButton);

                    seatNumber++;
                }
            }

            Button btnChon = new Button();
            btnChon.Text = "Chọn";
            btnChon.Left = 50;
            btnChon.Top = 300;
            btnChon.Click += BtnChon_Click;
            this.Controls.Add(btnChon);

            Button btnHuyBo = new Button();
            btnHuyBo.Text = "Hủy bỏ";
            btnHuyBo.Left = 150;
            btnHuyBo.Top = 300;
            btnHuyBo.Click += BtnHuyBo_Click;
            this.Controls.Add(btnHuyBo);

            Label lblTongTien = new Label();
            lblTongTien.Name = "lblTongTien";
            lblTongTien.Text = "Tổng tiền: 0 VND";
            lblTongTien.Left = 50;
            lblTongTien.Top = 350;
            lblTongTien.AutoSize = true;
            this.Controls.Add(lblTongTien);

            // Add Exit button
            Button btnKetThuc = new Button();
            btnKetThuc.Text = "Kết thúc";
            btnKetThuc.Left = 250;
            btnKetThuc.Top = 300;
            btnKetThuc.Click += BtnKetThuc_Click;
            this.Controls.Add(btnKetThuc);
        }

        private void SeatButton_Click(object sender, EventArgs e)
        {
            Button seatButton = sender as Button;
            int seatNumber = (int)seatButton.Tag;

            if (soldSeats.Contains(seatNumber))
            {
                MessageBox.Show($"Ghế số {seatNumber} đã được bán.");
            }
            else if (selectedSeats.Contains(seatNumber))
            {
                selectedSeats.Remove(seatNumber);
                seatButton.BackColor = Color.White;
            }
            else
            {
                selectedSeats.Add(seatNumber);
                seatButton.BackColor = Color.Green;
            }
        }

        private void BtnChon_Click(object sender, EventArgs e)
        {
            int totalAmount = 0;
            foreach (int seatNumber in selectedSeats)
            {
                soldSeats.Add(seatNumber);

                Button seatButton = GetSeatButtonByNumber(seatNumber);
                if (seatButton != null)
                {
                    seatButton.BackColor = Color.Yellow;
                }

                totalAmount += GetSeatPrice(seatNumber);
            }
            selectedSeats.Clear();

            Label lblTongTien = this.Controls.Find("lblTongTien", true)[0] as Label;
            lblTongTien.Text = $"Tổng tiền: {totalAmount} VND";
        }

        private void BtnHuyBo_Click(object sender, EventArgs e)
        {
            foreach (int seatNumber in selectedSeats)
            {
                Button seatButton = GetSeatButtonByNumber(seatNumber);
                if (seatButton != null)
                {
                    seatButton.BackColor = Color.White;
                }
            }
            selectedSeats.Clear();

            Label lblTongTien = this.Controls.Find("lblTongTien", true)[0] as Label;
            lblTongTien.Text = "Tổng tiền: 0 VND";
        }

        private void BtnKetThuc_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private Button GetSeatButtonByNumber(int seatNumber)
        {
            foreach (var kvp in seatButtons)
            {
                if (kvp.Value == seatNumber)
                {
                    return kvp.Key;
                }
            }
            return null;
        }

        private int GetSeatPrice(int seatNumber)
        {
            if (seatNumber >= 1 && seatNumber <= 5)
                return 30000;
            else if (seatNumber >= 6 && seatNumber <= 10)
                return 40000;
            else if (seatNumber >= 11 && seatNumber <= 15)
                return 50000;
            else if (seatNumber >= 16 && seatNumber <= 20)
                return 80000;
            else
                return 0;
        }

        // Add label_3 click event
        private void label3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("MÀN ẢNH");
        }
    }
}
