﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab02_02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dgv.CellClick += dgv_CellClick;
            opt_nam.CheckedChanged += opt_nam_CheckedChanged;
            opt_nu.CheckedChanged += opt_nu_CheckedChanged;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (combo_cn.Items.Count > 0)
            {
                combo_cn.SelectedIndex = 0;
            }
            opt_nu.Checked = true; 
            txt_tongnam.Text = "0"; 
            txt_tongnu.Text = "0";
            UpdateStudentCounts();
        }
        private void opt_nam_CheckedChanged(object sender, EventArgs e)
        {
            if (opt_nam.Checked)
            {
                opt_nu.Checked = false;
            }
        }

        private void opt_nu_CheckedChanged(object sender, EventArgs e)
        {
            if (opt_nu.Checked)
            {
                opt_nam.Checked = false;
            }
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
        // Ham tinh tong sinh vien
        private void UpdateStudentCounts()
        {
            int maleCount = 0;
            int femaleCount = 0;
            for (int i = 0; i < dgv.Rows.Count; i++)
            {
                if (dgv.Rows[i].Cells[2].Value != null)
                {
                    string gender = dgv.Rows[i].Cells[2].Value.ToString();
                    if (gender == "Nam")
                    {
                        maleCount++;
                    }
                    else if (gender == "Nữ")
                    {
                        femaleCount++;
                    }
                }
            }
            txt_tongnam.Text = maleCount.ToString();
            txt_tongnu.Text = femaleCount.ToString();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            // Tinh tong sinh vien nu sau khi nhap lieu
            int count = 0;
            for (int i = 0; i < dgv.Rows.Count; i++)
            {
                var cellValue = dgv.Rows[i].Cells[2].Value;
                if (cellValue != null && cellValue.ToString() == "Nữ")
                {
                    count++;
                }
            }
            txt_tongnu.Text = count.ToString();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Chon 1 dong trong bang thi hien thi nguoc lai thong tin cua cac sinh vien da chon o phan nhap lieu
            int selectedRow = e.RowIndex;
            DataGridViewRow row = dgv.Rows[selectedRow];
            txt_mssv.Text = row.Cells[0].Value.ToString();
            txt_ten.Text = row.Cells[1].Value.ToString();
            if (row.Cells[2].Value.ToString() == "Nữ")
            {
                opt_nu.Checked = true;
            }
            else
            {
                opt_nam.Checked = true;
            }
            txt_dtb.Text = row.Cells[3].Value.ToString();
            combo_cn.Text = row.Cells[4].Value.ToString();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            int count = 0;
            for (int i = 0; i < dgv.Rows.Count; i++)
            {
                var cellValue = dgv.Rows[i].Cells[2].Value;
                if (cellValue != null && cellValue.ToString() == "Nam")
                {
                    count++;
                }
            }
            txt_tongnam.Text = count.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private int GetSeletedRow(String StudentID)
        {
            for (int i = 0; i < dgv.Rows.Count; i++)
            {
                var cellValue = dgv.Rows[i].Cells[0].Value;
                if (cellValue != null && cellValue.ToString() == StudentID)
                {
                    return i;
                }
            }
            return -1;
        }
        private void InsertUpdate(int selectedRow)
        {
            // Lay thong tin tu form
            dgv.Rows[selectedRow].Cells[0].Value = txt_mssv.Text;
            dgv.Rows[selectedRow].Cells[1].Value = txt_ten.Text;
            dgv.Rows[selectedRow].Cells[2].Value = opt_nu.Checked ? "Nữ" : "Nam";
            dgv.Rows[selectedRow].Cells[3].Value = float.Parse(txt_dtb.Text).ToString();
            dgv.Rows[selectedRow].Cells[4].Value = combo_cn.Text;


        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Kiểm tra thông tin nhập vào
                if (string.IsNullOrWhiteSpace(txt_mssv.Text) ||
                    string.IsNullOrWhiteSpace(txt_ten.Text) ||
                    string.IsNullOrWhiteSpace(txt_dtb.Text))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin");
                    return;
                }

                // Kiểm tra định dạng tên sinh viên (chỉ cho phép chữ cái và khoảng trắng)
                if (!System.Text.RegularExpressions.Regex.IsMatch(txt_ten.Text, @"^[\p{L} \.'\-]+$"))
                {
                    MessageBox.Show("Tên sinh viên không hợp lệ. Vui lòng chỉ nhập chữ cái.");
                    return;
                }

                // Kiểm tra điểm trung bình
                if (!float.TryParse(txt_dtb.Text, out float dtb) || dtb < 0 || dtb > 10)
                {
                    MessageBox.Show("Điểm trung bình phải là số từ 0 đến 10");
                    return;
                }

                int selectedRow = GetSeletedRow(txt_mssv.Text);
                if (selectedRow == -1)
                {
                    // Thêm sinh viên mới
                    selectedRow = dgv.Rows.Add();
                    InsertUpdate(selectedRow);
                    MessageBox.Show("Thêm dữ liệu thành công", "Thông Báo", MessageBoxButtons.OK);
                }
                else
                {
                    // Cập nhật sinh viên
                    InsertUpdate(selectedRow);
                    MessageBox.Show("Cập nhật dữ liệu thành công", "Thông Báo", MessageBoxButtons.OK);
                }
                UpdateStudentCounts(); // Cập nhật tổng số sinh viên
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedRow = GetSeletedRow(txt_mssv.Text);
                if (selectedRow == -1)
                {
                    MessageBox.Show("Không tìm thấy sinh viên có mã số " + txt_mssv.Text);
                    return;
                }
                else
                {
                    DialogResult dialogResult = MessageBox.Show("Bạn có chắc chắn muốn xóa sinh viên có mã số " + txt_mssv.Text, "Xác nhận", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        dgv.Rows.RemoveAt(selectedRow);
                        MessageBox.Show("Xóa sinh viên thành công", "Thông Báo", MessageBoxButtons.OK);
                        UpdateStudentCounts(); // Update totals
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Nut thoat chuong trinh
            DialogResult dialogResult = MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình", "Xác nhận", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void combo_cn_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv.Rows[e.RowIndex];
                txt_mssv.Text = row.Cells[0].Value?.ToString();
                txt_ten.Text = row.Cells[1].Value?.ToString();
                string gender = row.Cells[2].Value?.ToString();
                if (gender == "Nữ")
                {
                    opt_nu.Checked = true;
                }
                else if (gender == "Nam")
                {
                    opt_nam.Checked = true;
                }
                txt_dtb.Text = row.Cells[3].Value?.ToString();
                combo_cn.Text = row.Cells[4].Value?.ToString();
            }
        }
    }
}
