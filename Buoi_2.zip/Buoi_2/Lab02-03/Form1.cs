﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab02_03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void InitializeSeatButtons()
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button19_Click(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {

        }

        private void button20_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button25_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {

        }
        //private void btnChooseASeat(object sender, EventArgs e)
        //{
        //    Button btn = sender as Button;
        //    if (btn.BackColor == Color.White)
        //    {
        //        btn.BackColor = Color.Blue;
        //    }
        //    else if (btn.BackColor == Color.Blue)
        //    {
        //        btn.BackColor = Color.White;
        //    }
        //    else if (btn.BackColor == Color.Yellow)
        //    {
        //        MessageBox.Show("This seat is already taken");
        //    }
        //}

        private void groupBox1_Enter(object sender, EventArgs e)
        {
           
        }
    }
}
