﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab02_01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Ham tinh tong
            int a, b;
            if (int.TryParse(txt_number1.Text, out a) && int.TryParse(txt_number2.Text, out b))
            {
                int c = a + b;
                txt_result.Text = c.ToString();
            }
            else
            {
                txt_result.Text = "Vui lòng nhập số hợp lệ";
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // Ham tinh thuong cua 2 so
            int a, b;
            if (int.TryParse(txt_number1.Text, out a) && int.TryParse(txt_number2.Text, out b))
            {
                if (b == 0)
                {
                    txt_result.Text = "Không thể chia cho 0";
                }
                else
                {
                    int c = a / b;
                    txt_result.Text = c.ToString();
                }
            }
            else
            {
                txt_result.Text = "Vui lòng nhập số hợp lệ";
            }
        }

        private void btn_sub_Click(object sender, EventArgs e)
        {
            // Ham tinh hieu
            int a, b;
            if (int.TryParse(txt_number1.Text, out a) && int.TryParse(txt_number2.Text, out b))
            {
                int c = a - b;
                txt_result.Text = c.ToString();
            }
            else
            {
                txt_result.Text = "Vui lòng nhập số hợp lệ";
            }
        }

        private void btn_mul_Click(object sender, EventArgs e)
        {
            // Ham tinh tich
            int a, b;
            if (int.TryParse(txt_number1.Text, out a) && int.TryParse(txt_number2.Text, out b))
            {
                int c = a * b;
                txt_result.Text = c.ToString();
            }
            else
            {
                txt_result.Text = "Vui lòng nhập số hợp lệ";
            }
        }

        private void txt_number1_Validating(object sender, CancelEventArgs e)
        {
            // Check xem txt_number1 co phai la so hay khong
            int a;
            if (!int.TryParse(txt_number1.Text, out a))
            {
                e.Cancel = true;
                txt_number1.Focus();
                errorProvider1.SetError(txt_number1, "Vui lòng nhập số hợp lệ");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txt_number1, null);
            }
        }

        private void txt_number2_Validating(object sender, CancelEventArgs e)
        {
            // Check xem txt_number2 co phai la so hay khong
            int a;
            if (!int.TryParse(txt_number2.Text, out a))
            {
                e.Cancel = true;
                txt_number2.Focus();
                errorProvider1.SetError(txt_number2, "Vui lòng nhập số hợp lệ");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txt_number2, null);
            }
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            // In ra hop thoai thong bao thoat
            DialogResult result = MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
