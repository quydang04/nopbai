﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab02_04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            if (!dgv_kh.Columns.Contains("STT"))
            {
                dgv_kh.Columns.Insert(0, new DataGridViewTextBoxColumn() { Name = "STT", HeaderText = "STT" });
            }

            
            AddDataGridViewColumns();

            dgv_kh.Sorted += dgv_kh_Sorted;
            dgv_kh.SelectionChanged += dgv_kh_SelectionChanged;
            UpdateSTT();
        }

        private void AddDataGridViewColumns()
        {
            if (!dgv_kh.Columns.Contains("SoTaiKhoan"))
            {
                dgv_kh.Columns.Add("SoTaiKhoan", "Số Tài Khoản");
            }
            if (!dgv_kh.Columns.Contains("TenKhachHang"))
            {
                dgv_kh.Columns.Add("TenKhachHang", "Tên Khách Hàng");
            }
            if (!dgv_kh.Columns.Contains("DiaChi"))
            {
                dgv_kh.Columns.Add("DiaChi", "Địa Chỉ");
            }
            if (!dgv_kh.Columns.Contains("SoTienTaiKhoan"))
            {
                dgv_kh.Columns.Add("SoTienTaiKhoan", "Số Tiền Tài Khoản");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void label4_Click(object sender, EventArgs e)
        {
           
        }

        private void label6_Click(object sender, EventArgs e)
        {
           
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
          
        }
        private void dgv_kh_SelectionChanged(object sender, EventArgs e)
        {
            if (dgv_kh.CurrentRow != null)
            {
                try
                {
                    // Lấy dòng đang được chọn
                    DataGridViewRow row = dgv_kh.CurrentRow;

                    // Hiển thị thông tin lên các textbox
                    txt_stk.Text = row.Cells["SoTaiKhoan"].Value?.ToString() ?? "";
                    txt_tkh.Text = row.Cells["TenKhachHang"].Value?.ToString() ?? "";
                    txt_dckh.Text = row.Cells["DiaChi"].Value?.ToString() ?? "";
                    txt_stttk.Text = row.Cells["SoTienTaiKhoan"].Value?.ToString() ?? "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Có lỗi khi hiển thị dữ liệu: " + ex.Message);
                }
            }
        }

        private void btn_themsua_Click(object sender, EventArgs e)
        {
            // Check input fields
            if (string.IsNullOrWhiteSpace(txt_stk.Text))
            {
                MessageBox.Show("Vui lòng nhập số tài khoản", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_stk.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(txt_tkh.Text))
            {
                MessageBox.Show("Vui lòng nhập tên khách hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_tkh.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(txt_dckh.Text))
            {
                MessageBox.Show("Vui lòng nhập địa chỉ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_dckh.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(txt_stttk.Text))
            {
                MessageBox.Show("Vui lòng nhập số tiền", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_stttk.Focus();
                return;
            }

            // Check if account number exists
            bool exists = false;
            int selectedRow = -1;
            for (int i = 0; i < dgv_kh.Rows.Count; i++)
            {
                if (dgv_kh.Rows[i].Cells["SoTaiKhoan"].Value != null &&
                    dgv_kh.Rows[i].Cells["SoTaiKhoan"].Value.ToString() == txt_stk.Text)
                {
                    selectedRow = i;
                    exists = true;
                    break;
                }
            }

            if (exists)
            {
                // Update existing record
                InsertUpdate(selectedRow);
            }
            else
            {
                // Add new record
                int newRow = dgv_kh.Rows.Add();
                dgv_kh.Rows[newRow].Cells["SoTaiKhoan"].Value = txt_stk.Text;
                dgv_kh.Rows[newRow].Cells["TenKhachHang"].Value = txt_tkh.Text;
                dgv_kh.Rows[newRow].Cells["DiaChi"].Value = txt_dckh.Text;
                dgv_kh.Rows[newRow].Cells["SoTienTaiKhoan"].Value = txt_stttk.Text;
            }


            // Update STT
            UpdateSTT();

            // Update total amount
            tinhTongSoTien();

            // Show success message
            MessageBox.Show("Thêm/Sửa thông tin tài khoản thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void InsertUpdate(int selectedRow)
        {
            // Get information from form
            dgv_kh.Rows[selectedRow].Cells["SoTaiKhoan"].Value = txt_stk.Text;
            dgv_kh.Rows[selectedRow].Cells["TenKhachHang"].Value = txt_tkh.Text;
            dgv_kh.Rows[selectedRow].Cells["DiaChi"].Value = txt_dckh.Text;
            dgv_kh.Rows[selectedRow].Cells["SoTienTaiKhoan"].Value = txt_stttk.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dgv_kh.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu để xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                DialogResult result = MessageBox.Show("Bạn có muốn xóa tài khoản này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    if (dgv_kh.CurrentRow != null && !dgv_kh.CurrentRow.IsNewRow)
                    {
                        dgv_kh.EndEdit();
                        dgv_kh.Rows.RemoveAt(dgv_kh.CurrentRow.Index);
                        MessageBox.Show("Xóa tài khoản thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        UpdateSTT();
                        // Recalculate total amount (if necessary)
                        tinhTongSoTien();
                    }
                    else
                    {
                        MessageBox.Show("Không thể xóa dòng mới chưa được lưu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void UpdateSTT()
        {
            for (int i = 0; i < dgv_kh.Rows.Count; i++)
            {
                dgv_kh.Rows[i].Cells["STT"].Value = i + 1;
            }
        }

        private void dgv_kh_Sorted(object sender, EventArgs e)
        {
            UpdateSTT();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            // Exit application
            DialogResult result = MessageBox.Show("Bạn có muốn thoát chương trình không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
         }

        private void txt_stk_TextChanged(object sender, EventArgs e)
        {
            // Kiem tra xem co trung so tai khoan khong va du lieu nhap vao co phai la mot con so hay khong va neu trung stk thi in ra thong bao
            if (txt_stk.Text.Any(c => !char.IsDigit(c)))
            {
                MessageBox.Show("Số tài khoản chỉ chứa ký tự số", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_stk.Text = string.Empty;
            }


        }

        private void txt_tkh_TextChanged(object sender, EventArgs e)
        {
            // Kiem tra ky tu dau vao co phai la chu cai hay khong neu khong phai thi in ra thong bao
            if (txt_tkh.Text.Any(c => char.IsDigit(c)))
            {
                MessageBox.Show("Tên khách hàng chỉ chứa ký tự chữ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_tkh.Text = string.Empty;
            }
        }

        private void txt_stttk_TextChanged(object sender, EventArgs e)
        {
            // Kiem tra xem du lieu nhap vao co phai la mot con so hay khong, neu khong thi in ra thong bao
            if (txt_stttk.Text.Any(c => !char.IsDigit(c)))
            {
                MessageBox.Show("Số tiền tài khoản chỉ chứa ký tự số", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_stttk.Text = string.Empty;
            }
        }
        // Ham tinh tong so tien
        private void tinhTongSoTien()
        {
            int tong = 0;
            for (int i = 0; i < dgv_kh.Rows.Count; i++)
            {
                var cellValue = dgv_kh.Rows[i].Cells["SoTienTaiKhoan"].Value;
                if (cellValue != null)
                {
                    tong += int.Parse(cellValue.ToString());
                }
            }
            txt_tongtien.Text = tong.ToString();
        }

        private void txt_tongtien_TextChanged(object sender, EventArgs e)
        {
            // Tinh tong so tien khi thay doi du lieu
            tinhTongSoTien();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tinhTongSoTien();
        }
    }
}
