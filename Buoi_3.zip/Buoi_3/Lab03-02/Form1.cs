﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab03_02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SetDefaultFontAndSize();
        }

        private void SetDefaultFontAndSize()
        {
            // Set default font to Tahoma
            toolStripComboBox1.Text = "Tahoma";
            richTextBox1.Font = new Font("Tahoma", richTextBox1.Font.Size);

            // Set default font size to 14
            toolStripComboBox2.Text = "14";
            richTextBox1.Font = new Font(richTextBox1.Font.FontFamily, 14);
        }

        private void địnhDạngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            fontDialog.ShowColor = true;
            fontDialog.ShowApply = true;
            fontDialog.ShowEffects = true;
            fontDialog.ShowHelp = true;
            if (fontDialog.ShowDialog() != DialogResult.Cancel)
            {
                richTextBox1.ForeColor = fontDialog.Color;
                richTextBox1.Font = fontDialog.Font;
            }
        }

        private void thoátChươngTrìnhToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Hien thi hop thoai thoat chuong trinh
            DialogResult result = MessageBox.Show("Bạn có muốn thoát chương trình không?", "Thoát chương trình", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void tạoVănBảnMớiToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void mởTậpTinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Mo tap tin van ban
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog.FilterIndex = 1;
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.LoadFile(openFileDialog.FileName, RichTextBoxStreamType.PlainText);
            }
        }

        private void lưuNộiDungVănBảnToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {
            // Lay tat ca cac font trong may dua vao combobox
            foreach (FontFamily font in FontFamily.Families)
            {
                toolStripComboBox1.Items.Add(font.Name);
            }
            // Tao font mac dinh tahoma
            toolStripComboBox1.Text = "Tahoma";
        }

        private void toolStripComboBox2_Click(object sender, EventArgs e)
        {
            // Tao du lieu cho combobox font tu 8 den 72
            for (int i = 8; i <= 72; i++)
            {
                toolStripComboBox2.Items.Add(i);
            }
            // Tao size mac dinh 14
            toolStripComboBox2.Text = "14";
        }
    }
}
