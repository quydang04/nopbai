﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab03_01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Resize += new EventHandler(Form1_Resize);
            // Khởi tạo Timer
            Timer timer1 = new Timer();
            timer1.Interval = 1000;
            timer1.Tick += new EventHandler(timer1_Tick);
            timer1.Start();
        }
        private void Form1_Resize(object sender, EventArgs e)
        {
            // Resize the media player and buttons based on the form size
            axWindowsMediaPlayer1.Width = this.ClientSize.Width - 20; // Leave some padding
            axWindowsMediaPlayer1.Height = this.ClientSize.Height - 100; // Adjust height accordingly
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            // Lay gio hien tai
            this.toolStripStatusLabel1.Text = string.Format("Hom nay la: {0} - Bay gio la: {1}", DateTime.Now.ToString("dd/MM/yyyy"), DateTime.Now.ToString("hh:mm:ss tt"));

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Hien thi hop thoai mo file
            OpenFileDialog open = new OpenFileDialog();
            // Cho hien thi toan bo tap tin duoi dang video
            open.Filter = "Video Files|*.mp4;*.flv;*.avi;*.mov;*.wmv";
            open.Title = "Chon file video";
            if (open.ShowDialog() == DialogResult.OK)
            {
                axWindowsMediaPlayer1.URL = open.FileName;
                // Thong bao thanh cong
                MessageBox.Show("Da mo file thanh cong", "Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Hien thi hop thoai thoat chuong trinh
            DialogResult result = MessageBox.Show("Ban co muon thoat chuong trinh khong?", "Thong bao", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Hien thi hop thoai thong tin chuong trinh
            MessageBox.Show("Chuong trinh xem video", "Thong tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

