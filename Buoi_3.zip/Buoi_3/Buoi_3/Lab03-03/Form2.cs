﻿using System;
using System.Windows.Forms;

namespace Lab03_03
{
    public partial class Form2 : Form
    {
        public Form1 MainForm { get; set; }

        public Form2()
        {
            InitializeComponent();
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txt_mssv.Text) ||
                    string.IsNullOrWhiteSpace(txt_ten.Text) ||
                    string.IsNullOrWhiteSpace(txt_dtb.Text))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin");
                    return;
                }

                if (!System.Text.RegularExpressions.Regex.IsMatch(txt_ten.Text, @"^[\p{L} \.'\-]+$"))
                {
                    MessageBox.Show("Tên sinh viên không hợp lệ. Vui lòng chỉ nhập chữ cái.");
                    return;
                }

                if (!float.TryParse(txt_dtb.Text, out float dtb) || dtb < 0 || dtb > 10)
                {
                    MessageBox.Show("Điểm trung bình phải là số từ 0 đến 10");
                    return;
                }

                // Truyền dữ liệu về Form1
                MainForm.AddStudent(txt_mssv.Text, txt_ten.Text, dtb, combo_cn.Text);

                MessageBox.Show("Thêm dữ liệu thành công", "Thông Báo", MessageBoxButtons.OK);

                this.Close(); // Đóng Form2 sau khi thêm
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Hien thi hop thoai khi thoat form
            DialogResult result = MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
