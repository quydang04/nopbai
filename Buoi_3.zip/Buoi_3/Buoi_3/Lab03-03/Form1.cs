﻿using System;
using System.Windows.Forms;

namespace Lab03_03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Cấu hình DataGridView
            dgv_student.ColumnCount = 4; // Thêm 3 cột chính ngoài STT
            dgv_student.Columns[0].Name = "STT";
            dgv_student.Columns[1].Name = "Mã Số SV";
            dgv_student.Columns[2].Name = "Tên Sinh Viên";
            dgv_student.Columns[3].Name = "Điểm Trung Bình";
            dgv_student.Columns.Add("Khoa", "Khoa"); // Cột chuyên ngành

            // Cấu hình cột STT
            dgv_student.Columns[0].ReadOnly = true; // STT chỉ đọc
        }

        public void AddStudent(string mssv, string ten, float dtb, string cn)
        {
            // Thêm dữ liệu vào DataGridView
            dgv_student.Rows.Add("", mssv, ten, dtb, cn);
            UpdateSTT(); // Cập nhật STT sau khi thêm
        }

        private void UpdateSTT()
        {
            for (int i = 0; i < dgv_student.Rows.Count; i++)
            {
                dgv_student.Rows[i].Cells[0].Value = (i + 1).ToString(); // Cập nhật STT theo thứ tự
            }
        }

        private void thêmMớiToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.MainForm = this; // Truyền tham chiếu đến Form1
            form2.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            // Đang để trống
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            thêmMớiToolStripMenuItem_Click_1(sender, e); // Mở form thêm mới khi nhấn vào ToolStrip
        }

        private void thoátChươngTrìnhToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Thoát chương trình
            DialogResult result = MessageBox.Show("Bạn có muốn thoát không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        // Tìm kiếm trong DataGridView
        private void toolStripTextBox1_TextChanged(object sender, EventArgs e)
        {
            string searchText = toolStripTextBox1.Text.ToLower();
            bool found = false;

            foreach (DataGridViewRow row in dgv_student.Rows)
            {
                if (row.IsNewRow) continue;

                var cell1Value = row.Cells[1].Value?.ToString().ToLower();
                var cell2Value = row.Cells[2].Value?.ToString().ToLower();

                if ((cell1Value != null && cell1Value.Contains(searchText)) ||
                    (cell2Value != null && cell2Value.Contains(searchText)))
                {
                    row.Visible = true;
                    found = true;
                }
                else
                {
                    row.Visible = false;
                }
            }

            if (!found)
            {
                MessageBox.Show("Không tìm thấy sinh viên nào!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {
            // Label dùng để tìm kiếm, gán hàm
            toolStripTextBox1_TextChanged(sender, e);
        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {
            // Không cần thực hiện thêm
        }
    }
}
